from etc import read_html

print(read_html("https://en.wikipedia.org/wik/HOK_(firm)"))

