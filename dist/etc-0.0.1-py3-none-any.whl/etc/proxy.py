def read_html(url):
    print("This is the url" + url)
